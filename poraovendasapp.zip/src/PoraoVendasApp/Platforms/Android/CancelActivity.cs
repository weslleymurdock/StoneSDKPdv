using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Widget;
using CommunityToolkit.Mvvm.Messaging;
using PoraoVendasApp.Messages;

namespace PoraoVendasApp;
[Activity(Label = "CancelActivity")]
[IntentFilter(new[] { Android.Content.Intent.ActionView },
              Categories = new[] { Android.Content.Intent.CategoryBrowsable, Android.Content.Intent.CategoryDefault },
              DataScheme = "poraovendasapp",
              DataHost = "cancel-response",
              AutoVerify = true
        )]
public class CancelActivity : Activity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        WeakReferenceMessenger.Default.Register<CancelMessage>(this, (r, m) =>
        {
            OnNewIntent(Intent);
        });
    }

    protected override void OnNewIntent(Intent intent)
    {
        base.OnNewIntent(intent);
        Android.Net.Uri.Builder uriBuilder = new Android.Net.Uri.Builder();
        uriBuilder.Authority("cancel");
        uriBuilder.Scheme("cancel-app");

        uriBuilder.AppendQueryParameter("returnscheme", "poraovendasapp");
        uriBuilder.AppendQueryParameter("atk", "atk");  
        uriBuilder.AppendQueryParameter("amount", "amount"); 
        uriBuilder.AppendQueryParameter("editable_amount", "false"); //true/false
         
        try
        {
            if (Intent!.Data != null)
            {
                WeakReferenceMessenger.Default.Send(new ReturnMessage(Intent!.DataString!));
            }
        }
        catch (Exception e)
        {
            WeakReferenceMessenger.Default.Send(new ReturnMessage(e.Message));
        }

        Intent i = new Intent(Intent.ActionView);
        i.AddFlags(ActivityFlags.NewTask);
        i.SetData(uriBuilder.Build());
        StartActivity(i);
    }
}
